<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="css/index-styles.css" />
    <link rel="stylesheet" href="css/About us-stules.css" />
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700;900&display=swap" rel="stylesheet" />
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css" />
    <title>Academic Information Management System</title>
</head>

<body>
    <nav>
        <div class="container navigation">
            <a href="index.php">
                <h1>AIMS</h1>
            </a>
            <ul class="nav-menu">
                <li><a href="index.php">Home</a></li>
                <li><a href="login-menu-options.php">Login</a></li>
                <li><a href="#">Events</a></li>
                <li><a href="#">Services</a></li>
                <li><a href="About-us.php">About</a></li>
            </ul>
        </div>
    </nav>

    <main>
        <section class="achivements">
            <div class="achivements-cont">
                <div class="achive-left">
                    <h1>Achivements</h1>
                    <p>
                        AIMS is a major website solution that helps with everything from admissions to student success.
                        AIMS is a typical application of managing academic information system, its development mainly includes
                        the backstage database the establishment and maintenance of and front-end application development two aspects.
                        For the former requirement to establish data consistency and integrality and security of data.
                    </p>
                    <div class="achive-cards">
                        <article class="achive-box">
                            <span class="achive-icon"><i class="uil uil-users-alt"></i></span>
                            <h3>77000+</h3>
                            <p>Users</p>
                        </article>
                        <article class="achive-box">
                            <span class="achive-icon"><i class="uil uil-files-landscapes-alt"></i></span>
                            <h3>5000+</h3>
                            <p>Resources</p>
                        </article>
                        <article class="achive-box">
                            <span class="achive-icon"><i class="uil uil-award"></i></span>
                            <h3>18</h3>
                            <p>Awards</p>
                        </article>
                    </div>
                </div>
                <div class="achive-right">
                    <img src="Images/achievement-award-medal-icon.svg" alt="" />
                </div>
            </div>
        </section>
        <section class="team">
            <h2>Meet Our Team</h2>
            <div class="container team-cont">
                <article class="member">
                    <div class="member-image">
                        <img src="Images/karib.jpg" alt="" />
                    </div>
                    <div class="member-info">
                        <h4>Abdur Rahman Faruk Khan</h4>
                        <p>Front-End Developer</p>
                        <p>abdur.khan04@northsouth.edu</p>
                    </div>
                    <div class="member-social">
                        <a href="https://www.facebook.com/media/set/?set=a.1389695924585688&type=3"><i class="uil uil-facebook-f"></i></a>
                    </div>
                </article>
                <article class="member">
                    <div class="member-image">
                        <img src="Images/jawadjpg.jpg" alt="" />
                    </div>
                    <div class="member-info">
                        <h4>Jawad Ibn Ahad</h4>
                        <p>Full-Stack Developer</p>
                        <p>jawadibnahad506277@gmail.com</p>
                    </div>
                    <div class="member-social">
                        <a href="https://www.facebook.com/jawadibn.ahad.77"><i class="uil uil-facebook-f"></i></a>
                    </div>
                </article>
                <article class="member">
                    <div class="member-image">
                        <img src="Images/zarin.jpg" alt="" />
                    </div>
                    <div class="member-info">
                        <h4>Zarin Akter</h4>
                        <p>Junior Designer</p>
                        <p>zarin.akter@northsouth.edu</p>
                    </div>
                    <div class="member-social">
                        <a href="https://www.facebook.com/zarinakter.adrika"><i class="uil uil-facebook-f"></i></a>
                    </div>
                </article>
            </div>
        </section>
    </main>

    <footer>
        <div class="cont foot-cont">
            <div class="foot-1">
                <a href="homepage.html" class="footer-logo">
                    <h2>AICM</h2>
                </a>
                <p>
                    A complete academic information management system.
                </p>
            </div>
            <div class="foot-2">
                <h4>Links</h4>
                <ul class="Links">
                    <li><a href="homepage.html">Home</a></li>
                    <li><a href="homepage.html">Events</a></li>
                    <li><a href="homepage.html">Services</a></li>
                    <li><a href="About Us.html">About</a></li>
                </ul>
            </div>
            <div class="foot-3">
                <h4>Contuct Us</h4>
                <p>+08801105128635</p>
                <p>abdur.khan04@northsouth.edu</p>
                <p>zarin.akter@northsouth.edu</p>
                <p>jawadibnahad506277@gmail.com</p>
            </div>
        </div>
    </footer>
</body>

</html>